<html>
<head>
    <title>xd</title>
</head>
<body>
<form action="/api/upload" method="post" enctype="multipart/form-data">
    <input type="file" name="file"> <br>
    <input type="submit">
</form>
</body>
</html>